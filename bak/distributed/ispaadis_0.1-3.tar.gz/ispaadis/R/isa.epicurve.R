isa.epicurve <- function (dat, model, stats = FALSE, type = "cumulative", quant = c(0.25, 0.75)){
  # ISP input: itno, day, premises identifier.
  # AADIS input: itno, day, number of events.
  
  require(tidyr); require(dplyr)
  
  # Re-format ISP data to return the number of events per day (instead of one line for each event):
  if(model == "isp"){
    
    dat$evt <- 1
    names(dat)[1:3] <- c("itno", "day", "hid")
    head(dat)
    
    # Set column 2 (day) as a factor:
    dmin <- min(dat$day); dmax <- max(dat$day)
    dseq <- seq(from = dmin, to = dmax, by = 1)
    dat$fday <- factor(dat$day, levels = dseq)
    
    .dat <- dat %>%
      group_by(itno, fday) %>%
      summarise(n = n()) %>%
      complete(itno, fday, fill = list(n = 0, freq = 0))
    .dat <- data.frame(.dat)
    names(.dat) <- c("itno","fday","n")
    head(.dat)
  }
  
  q01.fun <- function(dat) {quantile(dat, probs = quant[1])}
  q02.fun <- function(dat) {quantile(dat, probs = quant[2])}
  itno <- max(dat$itno)
  
  if (stats == TRUE) {
    out <- matrix(rep(NA, times = length(dseq) * itno), ncol = itno)
    
    for (i in 1:itno) {
      id <- dat$itno == i
      tdat <- data.frame(dat[id,])
      
      for (j in 1:length(dseq)) {
        if (type == "cumulative"){
          out[j,i] <- sum(tdat$evt[tdat$day <= dseq[j]])
          # n <- cumsum(tmp.01$evt)
        }
        
        if (type == "frequency") {
          out[j,i] <- ifelse(length(tdat$evt[tdat$day == dseq[j]]) == 0, 0, tdat$evt[tdat$day == dseq[j]])
        }
      }
    }
    
    rmean <- apply(out, MARGIN = 1, FUN = mean)
    rsd <- apply(out, MARGIN = 1, FUN = sd)
    rmed <- apply(out, MARGIN = 1, FUN = median)
    rq01 <- apply(out, MARGIN = 1, FUN = q01.fun)
    rq02 <- apply(out, MARGIN = 1, FUN = q02.fun)
    rmin <- apply(out, MARGIN = 1, FUN = min)
    rmax <- apply(out, MARGIN = 1, FUN = max)
    
    q01.n <- paste("pr.", quant[1] * 100, sep = "")
    q02.n <- paste("pr.", quant[2] * 100, sep = "")
    rval <- data.frame(dseq, rmean, rsd, rmed, rq01, rq02, rmin, rmax)
    names(rval) <- c("day", "pr.mean", "pr.sd", "pr.median", q01.n, q02.n, "pr.min", "pr.max")
  }
  
  else if (stats == FALSE) {
    out <- matrix(rep(NA, times = length(dseq) * (itno + 1)), ncol = itno + 1)
    out[,1] <- dseq
    
    for (i in 1:itno) {
      id <- dat$itno == i
      tdat <- data.frame(dat[id,])
      
      for (j in 1:length(dseq)) {
        if (type == "cumulative"){
          out[j,i + 1] <- sum(tdat$evt[tdat$day <= dseq[j]])
          # n <- cumsum(tmp.01$evt)
        }
        
        if (type == "frequency") {
          out[j,i] <- tdat$evt[tdat$day == dseq[j]]
        }
      }
    }
    
    # Fix up the dimension names of rval:
    .itno <- 1:itno
    .cname <- as.character(1:itno)
    .cname[.itno < 10] <- paste("i000", .cname[.itno < 10], sep = "")
    .cname[.itno >= 10 & .itno < 100] <- paste("i00", .cname[.itno >= 10 & .itno < 100], sep = "")
    .cname[.itno >= 100 & .itno < 1000] <- paste("i0", .cname[.itno >= 100 & .itno < 1000], sep = "")
    .cname[.itno >= 1000] <- paste("i", .cname[.itno >= 1000], sep = "")
    colnames(out) <- c("day", .cname)
    rval <- out
  }
  
  rval

}