isa.epicurve <- function (dat, model, stats = FALSE, type = "cumulative", quant = c(0.25, 0.75)){
    # ISP input: itno, day, premises identifier.
    # AADIS input: itno, day, number of events.

    # Re-format ISP data to return the number of events per day (instead of one line for each event):
    if(model == "isp"){
      .dat <- by(data = dat[,2], INDICES = list(dat[,2], dat[,1]), FUN = length)
      names <- expand.grid(dimnames(.dat)[[1]], dimnames(.dat)[[2]])
      .dat <- data.frame(names, evt = as.numeric(.dat))
      
      dat <- data.frame(itno = .dat$Var2, day = .dat$Var1, evt = .dat$evt)
      dat$itno <- as.numeric(levels(dat$itno))[dat$itno]
      dat$day <- as.numeric(levels(dat$day))[dat$day]
      dat$evt[is.na(dat$evt)] <- 0
    }
  
  n.iterations <- max(dat$itno)  
  names(dat) <- c("itno", "day", "evt")
  day.seq <- seq(min(dat$day), max(dat$day), by = 1)
  
  q01.fun <- function(dat) {
    quantile(dat, probs = quant[1])
  }
  q02.fun <- function(dat) {
    quantile(dat, probs = quant[2])
  }
  
  if (stats == TRUE) {
    out <- matrix(rep(NA, times = length(day.seq) * n.iterations), ncol = n.iterations)
    
    for (i in 1:n.iterations) {
      id <- dat$itno == i
      tdat <- data.frame(dat[id,])
      
      for (j in 1:length(day.seq)) {
        if (type == "cumulative"){
          out[j,i] <- sum(tdat$evt[tdat$day <= day.seq[j]])
          # n <- cumsum(tmp.01$evt)
        }
        
        if (type == "frequency") {
          out[j,i] <- ifelse(length(tdat$evt[tdat$day == day.seq[j]]) == 0, 0, tdat$evt[tdat$day == day.seq[j]])
        }
      }
    }
    
    rmean <- apply(out, MARGIN = 1, FUN = mean)
    rsd <- apply(out, MARGIN = 1, FUN = sd)
    rmed <- apply(out, MARGIN = 1, FUN = median)
    rq01 <- apply(out, MARGIN = 1, FUN = q01.fun)
    rq02 <- apply(out, MARGIN = 1, FUN = q02.fun)
    rmin <- apply(out, MARGIN = 1, FUN = min)
    rmax <- apply(out, MARGIN = 1, FUN = max)
    
    q01.n <- paste("pr.", quant[1] * 100, sep = "")
    q02.n <- paste("pr.", quant[2] * 100, sep = "")
    rval <- data.frame(day.seq, rmean, rsd, rmed, rq01, rq02, rmin, rmax)
    names(rval) <- c("day", "pr.mean", "pr.sd", "pr.median", q01.n, q02.n, "pr.min", "pr.max")
  }
  
  else if (stats == FALSE) {
    out <- matrix(rep(NA, times = length(day.seq) * (n.iterations + 1)), ncol = n.iterations + 1)
    out[,1] <- day.seq
    
    for (i in 1:n.iterations) {
      id <- dat$itno == i
      tdat <- data.frame(dat[id,])
      
      for (j in 1:length(day.seq)) {
        if (type == "cumulative"){
          out[j,i + 1] <- sum(tdat$evt[tdat$day <= day.seq[j]])
          # n <- cumsum(tmp.01$evt)
        }
        
        if (type == "frequency") {
          out[j,i] <- tdat$evt[tdat$day == day.seq[j]]
        }
      }
    }
    
    # Fix up the dimension names of rval:
    .itno <- 1:n.iterations
    .cname <- as.character(1:n.iterations)
    .cname[.itno < 10] <- paste("i000", .cname[.itno < 10], sep = "")
    .cname[.itno >= 10 & .itno < 100] <- paste("i00", .cname[.itno >= 10 & .itno < 100], sep = "")
    .cname[.itno >= 100 & .itno < 1000] <- paste("i0", .cname[.itno >= 100 & .itno < 1000], sep = "")
    .cname[.itno >= 1000] <- paste("i", .cname[.itno >= 1000], sep = "")
    colnames(out) <- c("day", .cname)
    rval <- out
  }
  
  rval
}